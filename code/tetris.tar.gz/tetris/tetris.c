/* tetris.c --- 
 * 
 * Copyright (c) 2008, suchaaa@gmail.com
 * 
 * Author:  Su Chang (suchaaa@gmail.com)
 * Maintainer: 
 * 
 * Created: 2008/11/27 12:40
 * Last-Updated: 2008/12/31 16:45
 * 
 */

/* Commentary: 
 * 
 *  a tetris game in ASCII under GNU/Linux
 */

/* Code: */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <termio.h>
#include <fcntl.h>
#include <assert.h>

/* debug
 */
#ifdef TETRIS_DEBUG
#define PERR(fmt, args...)                                              \
    do {                                                                \
        static FILE *fp = NULL;                                         \
        if (!fp)                                                        \
            fp = fopen("log.txt", "w");                                 \
        fprintf(fp, "<%s:%d> "fmt,__FUNCTION__, __LINE__, ##args);      \
    } while (0)
#else
#define PERR(fmt, args...) do {} while (0)
#endif

/* return status
 */
#define TE_OK   0
#define TE_ERR  -1

/* define the game square
 */
#define COL_MIN 0
//#define COL_MAX 40
#define COL_MAX 20
#define ROW_MIN 0
#define ROW_MAX 20
#define COL_MID ((COL_MAX - COL_MIN)>>1)

#define OFF_SET 5

#define SPEED_VAL 400

#define TETRIS_BLOCKS 4
#define TETRIS_TYPES  7         /* 7 shapes at most */

#define CLEAR_SCR()  system("clear")

typedef unsigned int bool;

enum {
    false = 0,
    true
};

typedef char sc;

typedef struct tag_Block {
    sc x;                       /* x, y to mark a block in screen */
    sc y;
    struct tag_Block *pn;
} Block;

typedef struct tag_Tetris {
    sc type;                   /* 7 types */
    sc form;
    sc total_form;
    Block *pb;
} Tetris;

static char g_line_marks[ROW_MAX];
static char g_bquit;
static int  g_erase_lines;


/* fill in tetris blk, blk[] store the x, y from 0, 1, ..., 6, 7
 */
int
fill_tetris_blk(Tetris *pt, sc blk[])
{
    int i = 0;
    Block *pb = NULL;

    assert(pt != NULL);

    pb = pt->pb;
    for (i=0; pb!=NULL; pb=pb->pn, i+=2)
    {
        pb->x = blk[i];
        pb->y = blk[i+1];
    }
    
    return TE_OK;
}

int
get_tetris_blk(Tetris *pt, sc blk[])
{
    int i = 0;
    Block *pb = NULL;

    assert(pt != NULL);

    pb = pt->pb;
    for (i=0; pb!=NULL; pb=pb->pn, i+=2)
    {
        blk[i] = pb->x;
        blk[i+1] = pb->y;
    }

    return TE_OK;
}


/* DONE ! */
/* generate a tetris, there is 7 types tetris, and every tetris have 4
 * shape, needed 4 blocks, the types with shape 0 will be:
 *
 *  0.T    1.I    2.Z    3.S    4.L   5.J    6.M
 *
 *   #      #     ##      ##     #      #     ##
 *  ###     #      ##    ##      #      #     ##
 *          #                    ##    ##
 *          #
 *
 * and the micro block's sequence within them will be top->down then
 * left->right. Take 0.T for example:
 *
 *      0x0
 *  0x1 0x2 0x3
 */
int
generate_a_tetris(Tetris **ppt)
{
    int i;
    Block **pbn = NULL;
    
    /* malloc a tetris
     */
    *ppt = (Tetris*)malloc(sizeof(Tetris));

    if (*ppt == NULL)
    {
        return TE_ERR;
    }
    
    pbn = &(*ppt)->pb;
    for (i = 0; i < TETRIS_BLOCKS; i++)
    {
        *pbn = (Block*)malloc(sizeof(Block));

        if (*pbn == NULL)
        {
            exit(EXIT_FAILURE);
        }

        (*pbn)->pn = NULL;
        pbn = &(*pbn)->pn;
    }
    
    
    /* rand its types
     */
    srand((unsigned int)time(NULL));
    (*ppt)->type = rand() % TETRIS_TYPES;
    (*ppt)->form = 0;

    /* TESTING */
/*     printf("type = %d, form = %d\n", (*ppt)->type, (*ppt)->form); */
/*     (*ppt)->type = 6; */
/*     (*ppt)->form = 0; */
    /* TESTING */
    
    switch ((*ppt)->type)
    {
        case 0:                 /* 0.T */
        {
            sc blk[] = { COL_MID    , ROW_MIN,
                         COL_MID - 1, ROW_MIN + 1,
                         COL_MID    , ROW_MIN + 1,
                         COL_MID + 1, ROW_MIN + 1 };
            fill_tetris_blk(*ppt, blk);
            (*ppt)->total_form = 4;
            break;
        }
        case 1:                 /* 1.I */
        {
            sc blk[] = { COL_MID - 2, ROW_MIN,
                         COL_MID - 1, ROW_MIN,
                         COL_MID    , ROW_MIN,
                         COL_MID + 1, ROW_MIN};
            fill_tetris_blk(*ppt, blk);
            (*ppt)->total_form = 2;
            break;
        }
        case 2:                 /* 2.Z */
        {
            sc blk[] = { COL_MID - 1, ROW_MIN,
                         COL_MID    , ROW_MIN,
                         COL_MID    , ROW_MIN + 1,
                         COL_MID + 1, ROW_MIN + 1};
            fill_tetris_blk(*ppt, blk);
            (*ppt)->total_form = 2;
            break;
        }
        case 3:                 /* 3.S */
        {
            sc blk[] = { COL_MID    , ROW_MIN,
                         COL_MID + 1, ROW_MIN,
                         COL_MID - 1, ROW_MIN + 1,
                         COL_MID    , ROW_MIN + 1,};
            fill_tetris_blk(*ppt, blk);
            (*ppt)->total_form = 2;
            break;
        }
        case 4:                 /* 4.L */
        {
            sc blk[] = { COL_MID    , ROW_MIN,
                         COL_MID + 1, ROW_MIN,
                         COL_MID + 2, ROW_MIN,
                         COL_MID   , ROW_MIN + 1,};
            fill_tetris_blk(*ppt, blk);
            (*ppt)->total_form = 4;
            break;
        }
        case 5:                 /* 5.J */
        {
            sc blk[] = { COL_MID - 2, ROW_MIN,
                         COL_MID - 1, ROW_MIN,
                         COL_MID    , ROW_MIN,
                         COL_MID    , ROW_MIN + 1};
            fill_tetris_blk(*ppt, blk);
            (*ppt)->total_form = 4;
            break;
        }
        case 6:                 /* 6.M */
        {
            sc blk[] = { COL_MID    , ROW_MIN,
                         COL_MID + 1, ROW_MIN,
                         COL_MID    , ROW_MIN + 1,
                         COL_MID + 1, ROW_MIN + 1,};
            fill_tetris_blk(*ppt, blk);
            (*ppt)->total_form = 1;
            break;
        }
        default:
            assert(0);
            return TE_ERR;
    }

    return TE_OK;
}

/* DONE !*/
/* tetris rotation of T, 0.T
 */
int
rotate_t(Tetris *pt)
{
    if (pt == NULL)
        return TE_ERR;

    /*  0.T
     *   0     1     2     3
     *   #     #           #
     *  ###    ##   ###   ##
     *         #     #     #
     */
    switch (pt->form)
    {

        case 0:         /* transform from 3. */
        {
            sc blk[8];
            get_tetris_blk(pt, blk);
            blk[2] -= 1;
            blk[4] -= 1;
            blk[6] += 1;
            blk[7] -= 1;
            fill_tetris_blk(pt, blk);
            break;
        }
        case 1:
        {
            sc blk[8];
            get_tetris_blk(pt, blk);
            blk[6] -= 1;
            blk[7] += 1;
            fill_tetris_blk(pt, blk);
            break;
        }
        case 2:
        {
            sc blk[8];
            get_tetris_blk(pt, blk);
            blk[0] -= 1;
            blk[1] += 1;
            blk[2] += 1;
            blk[4] += 1;
            fill_tetris_blk(pt, blk);
            break;
        }
        case 3:
        {
            sc blk[8];
            get_tetris_blk(pt, blk);
            blk[0] += 1;
            blk[1] -= 1;
            fill_tetris_blk(pt, blk);
            break;
        }
    }

    return TE_OK;
}

int
rotate_i(Tetris *pt)
{
    if (pt == NULL)
        return TE_ERR;

    /*  1.I
     *  0      1
     *  ####   #
     *         #
     *         #
     *         #
     */
    switch (pt->form)
    {
        case 0:
        {
            sc blk[8];
            get_tetris_blk(pt, blk);
            blk[2] += 1;
            blk[3] -= 1;
            blk[4] += 2;
            blk[5] -= 2;
            blk[6] += 3;
            blk[7] -= 3;
            fill_tetris_blk(pt, blk);
            break;
        }
        case 1:
        {
            sc blk[8];
            get_tetris_blk(pt, blk);
            blk[2] -= 1;
            blk[3] += 1;
            blk[4] -= 2;
            blk[5] += 2;
            blk[6] -= 3;
            blk[7] += 3;
            fill_tetris_blk(pt, blk);
            break;
        }
    }

    return TE_OK;
}

int
rotate_z(Tetris *pt)
{
    if (pt == NULL)
        return TE_ERR;

    /* 2.Z
     *   0       1
     *           #
     *  ##      ##
     *   ##     #
     */
    switch (pt->form)
    {
        case 0:
        {
            sc blk[8];
            get_tetris_blk(pt, blk);
            blk[0] -= 1;
            blk[1] += 1;
            blk[2] += 1;
            blk[5] += 1;
            blk[6] += 2;
            fill_tetris_blk(pt, blk);
            break;
        }
        case 1:
        {
            sc blk[8];
            get_tetris_blk(pt, blk);
            blk[0] += 1;
            blk[1] -= 1;
            blk[2] -= 1;
            blk[5] -= 1;
            blk[6] -= 2;
            fill_tetris_blk(pt, blk);
            break;
        }
    }

    return TE_OK;
}

int
rotate_s(Tetris *pt)
{
    if (pt == NULL)
        return TE_ERR;

    /* 3.S
     *  0       1
     *          #
     *  ##      ##
     * ##        #
     *
     */
    switch (pt->form)
    {
        case 0:
        {
            sc blk[8];
            get_tetris_blk(pt, blk);
            blk[0] += 1;
            blk[2] += 2;
            blk[3] -= 1;
            blk[4] -= 1;
            blk[7] -= 1;
            fill_tetris_blk(pt, blk);
            break;
        }
        case 1:
        {
            sc blk[8];
            get_tetris_blk(pt, blk);
            blk[0] -= 1;
            blk[2] -= 2;
            blk[3] += 1;
            blk[4] += 1;
            blk[7] += 1;
            fill_tetris_blk(pt, blk);
            break;
        }
    }

    return TE_OK;
}

int
rotate_l(Tetris *pt)
{
    if (pt == NULL)
        return TE_ERR;
    /* 4.L
     *  0      1      2    3
     *         #
     *         #      #
     *  ###    ##   ###   ##   
     *  #                  # 
     *                     #
     */
    switch (pt->form)
    {
        case 0:
        {
            sc blk[8];
            get_tetris_blk(pt, blk);
            blk[0] += 1;
            blk[2] += 1;
            blk[4] += 2;
            blk[5] -= 1;
            blk[7] -= 1;
            fill_tetris_blk(pt, blk);
            break;
        }
        case 1:
        {
            sc blk[8];
            get_tetris_blk(pt, blk);
            blk[1] -= 2;
            blk[2] -= 1;
            blk[3] -= 1;
            blk[4] -= 2;
            blk[6] += 1;
            blk[7] -= 1;
            fill_tetris_blk(pt, blk);
            break;
        }
        case 2:
        {
            sc blk[8];
            get_tetris_blk(pt, blk);
            blk[1] += 1;
            blk[2] -= 2;
            blk[3] += 1;
            blk[4] -= 1;
            blk[6] -= 1;
            fill_tetris_blk(pt, blk);
            break;
        }
        case 3:
        {
            sc blk[8];
            get_tetris_blk(pt, blk);
            blk[0] -= 1;
            blk[1] += 1;
            blk[2] += 2;
            blk[4] += 1;
            blk[5] += 1;
            blk[7] += 2;
            fill_tetris_blk(pt, blk);
            break;
        }
    }

    return TE_OK;
}

int
rotate_j(Tetris *pt)
{
    if (pt == NULL)
        return TE_ERR;

    /* 5.J
     *  0    1    2     3
     *  #
     *  #               #
     * ##  ###    ##    ###
     *       #    #
     *            #
     */  
    switch (pt->form)
    {
        case 0:
        {
            sc blk[8];
            get_tetris_blk(pt, blk);
            blk[0] -= 2;
            blk[1] += 2;
            blk[2] -= 1;
            blk[3] += 1;
            blk[4] += 1;
            blk[7] += 1;
            fill_tetris_blk(pt, blk);
            break;
        }
        case 1:
        {
            sc blk[8];
            get_tetris_blk(pt, blk);
            blk[0] += 2;
            blk[2] += 2;
            blk[5] += 1;
            blk[7] += 1;
            fill_tetris_blk(pt, blk);
            break;
        }
        case 2:
        {
            sc blk[8];
            get_tetris_blk(pt, blk);
            blk[1] -= 1;
            blk[2] -= 1;
            blk[4] += 1;
            blk[5] -= 1;
            blk[6] += 2;
            blk[7] -= 2;
            fill_tetris_blk(pt, blk);
            break;
        }
        case 3:
        {
            sc blk[8];
            get_tetris_blk(pt, blk);
            blk[1] -= 1;
            blk[3] -= 1;
            blk[4] -= 2;
            blk[6] -= 2;
            fill_tetris_blk(pt, blk);
            break;
        }
    }

    return TE_OK;
}

/* DONE ! */
/* rotate tetris, every types have 4 different rotation, but some
 * rotations of 1.I and 6.M looks like.
 */
int
rotate_tetris(Tetris *pt)
{
    /* Add restriction when tetris meets with borders
     */
    
    /* the rotation is anticlockwised
     */
    switch (pt->type)
    {
        case 0:
            rotate_t(pt);
            break;

        case 1:
            rotate_i(pt);
            break;

        case 2:
            rotate_z(pt);
            break;

        case 3:
            rotate_s(pt);
            break;

        case 4:
            rotate_l(pt);
            break;

        case 5:
            rotate_j(pt);
            break;

        case 6:
            /* 6.M
               0
               ## 
               ##
            */
            /* no rotation ! */
            break;

        default:
            break;
    }

    return TE_OK;
}

/* DONE ! */
/* move the tetris one block with direction, directions will be: */
enum {
    TO_LEFT,
    TO_RIGHT,
    TO_UP,
    TO_DOWN,
};
int
move_tetris(Tetris *pt, int direction)
{
    sc blk[8];

    assert (pt != NULL);

    if (0)                      /* debug */
    {
        Block *p;
        for (p=pt->pb; p; p=p->pn)
            printf("%d ", p->x);
        printf("\n");
    }

    get_tetris_blk(pt, blk);
    if (direction == TO_LEFT
        || direction == TO_RIGHT)
    {
        direction = direction==TO_LEFT ? -1 : 1;
        blk[0] += direction;
        blk[2] += direction;
        blk[4] += direction;
        blk[6] += direction;
    }
    else if (direction == TO_UP
             || direction == TO_DOWN)
    {
        direction = direction==TO_UP ? -1 : 1;
        blk[1] += direction;
        blk[3] += direction;
        blk[5] += direction;
        blk[7] += direction;
    }
    fill_tetris_blk(pt, blk);

    if (0)                      /* debug */
    {
        Block *p;
        for (p=pt->pb; p; p=p->pn)
            printf("%d ", p->x);
        printf("\n");
    }


    return TE_OK;
}

/* DONE ! */
/* if tetries collide with dirty blocks or panel border, return true, else false */
#define EQUAL_POINT(p1, p2) ((p1)->x==p2->x && (p1)->y==(p2)->y ? 1 : 0)
#define MEET_BORDER(p) ((p)->x<COL_MIN || (p)->x>=COL_MAX || (p)->y<COL_MIN || (p)->y>=ROW_MAX)
bool
is_tetris_collide(Tetris *pt, Block *pbd)
{
    Block *ptb, *p;

    if (pt == NULL)
        return false;

    for (p=pt->pb; p!=NULL; p=p->pn)
        if (MEET_BORDER(p))
            return true;

    for (ptb=pt->pb; ptb!=NULL; ptb=ptb->pn)
        for (p=pbd; p!=NULL; p=p->pn)
            if (EQUAL_POINT(ptb, p))
                return true;

    return false;
}


/* DONE ! */
/* if tetris collide blocks, connect them */
int
connect_tetris_and_blocks(Tetris **pt, Block **pbd)
{
    Block *p;

    assert(pt != NULL);
    assert(pbd != NULL);

    if (*pbd == NULL)
    {
        *pbd = (*pt)->pb;
        (*pt)->pb = NULL;
        free(*pt);
        *pt = NULL;
        return TE_OK;
    }

    for (p=*pbd; p->pn!=NULL; p=p->pn);

    p->pn = (*pt)->pb;
    (*pt)->pb = NULL;

    free(*pt);
    *pt = NULL;
    return TE_OK;
}

/* DONE ! */
/* calculate the mark of dirty blocks */
int
calc_line_marks_of_blocks(Tetris *pt)
{
    Block *pb = NULL;

    if (pt == NULL)
        return TE_ERR;

    for (pb=pt->pb; pb!=NULL; pb=pb->pn)
    {
        assert(pb->y >= ROW_MIN);
        assert(pb->y < ROW_MAX);
        g_line_marks[(unsigned char)pb->y]++;
//        PERR("line %d, marks %d\n", pb->y, g_line_marks[(unsigned char)pb->y]);
    }
    
    return TE_OK;
}

/* DONE ! */
/* update the marks of dirty blocks after remove the older ones,
   assumption the remove line have marks as 0 */
int
update_line_marks_of_blocks(Block *pbd)
{
    int i;
    Block *p;

    for (i=ROW_MIN; i<ROW_MAX; i++)
        g_line_marks[i] = 0;

    for (p=pbd; p!=NULL; p=p->pn)
    {
//        PERR("y = %d\n", (unsigned char)p->y);
        assert(p->y >= ROW_MIN);
        assert(p->y < ROW_MAX);
        g_line_marks[(unsigned char)p->y]++;
    }

    return TE_OK;
}




/* DONE ! */
/* mark the tetris' blocks and dirty blocks into the screen buffer */
int
mark_in_scr_buf(Tetris *pt, Block *pbd, sc *pscr)
{
    int i;
    Block *pb = NULL;

    if (pt==NULL || pscr==NULL) /* pbd==NULL are permitted */
        return TE_ERR;
    
    for (i=0; i<COL_MAX*ROW_MAX; i++)
    {
        *(pscr + i) = ' ';
    }
    
    for (pb=pt->pb; pb!=NULL; pb=pb->pn)
    {
        assert(pb->x<COL_MAX && pb->y<ROW_MAX);
        *(pscr + pb->x + pb->y*COL_MAX) = '#';
    }

    for (pb=pbd; pb!=NULL; pb=pb->pn)
    {
        assert(pb->x<COL_MAX && pb->y<ROW_MAX);
        *(pscr + pb->x + pb->y*COL_MAX) = '#';
    }

    return TE_OK;
}


/* DONE ! */
/* reset scr, then fill in the tetris and bottom blocks. */
int
invalidate_screen(sc *pscr)
{
    int y, x, i;

    if (pscr == NULL)
        return TE_ERR;

    for (y=ROW_MIN; y<ROW_MAX; y++)
    {
        for (i=0; i<OFF_SET; i++)
            printf(" ");
        printf("|");

        for (x=COL_MIN; x < COL_MAX; x++)
            printf("%c", *(pscr + x + y*COL_MAX));
//            printf("%c", (x%26) + 'a');

        if (y == OFF_SET-1)
        {
            printf("|  SCORE\n");
        }
        else if (y == OFF_SET)
        {
            printf("|    %d\n", g_erase_lines);
        }
        else
            printf("|\n");
    }
    
    for (i=0; i<OFF_SET+COL_MAX+OFF_SET+OFF_SET; i++)
        if (i==OFF_SET || i==OFF_SET+COL_MAX+1)
            printf("+");
        else
            printf("-");
    printf("\n");
        

    return TE_OK;
}

/* DONE ! */
/* remove blocks when it fullfill one line */
bool
be_remove_blocks_when_full(Block **pbd)
{
    int i, bremoved = false;
    Block **ppb, *pd;

    if (*pbd == NULL)
        return false;

    for (i=ROW_MIN; i<ROW_MAX; i++)
        if (g_line_marks[i] == COL_MAX)
        {
            for (ppb=pbd; *ppb!=NULL; ) /* check from head */
                if ((*ppb)->y == i)
                {
                    pd = *ppb;
                    *ppb = pd->pn;
                    free(pd);
                    g_line_marks[i]--;
//                    PERR("line %d, num %d\n", i, g_line_marks[i]);
                }
                else
                    ppb=&(*ppb)->pn;

            for (ppb=pbd; *ppb!=NULL; ppb=&(*ppb)->pn)
            {
                if ((*ppb)->y < i)
                    (*ppb)->y++;
//                PERR("x %d, y %d\n", (*ppb)->x, (*ppb)->y);
                assert((*ppb)->x>=COL_MIN && (*ppb)->x<COL_MAX);
                assert((*ppb)->y>=ROW_MIN && (*ppb)->y<ROW_MAX);
            }
            
            if (g_line_marks[i] != 0)
                PERR("remove error!\n");

            bremoved = true;
            g_erase_lines++;
        }

    return bremoved;
}

/* DONE ! */
/* control tetris moving and avoid it exceed panel */
int
control_tetris_and_wait(Tetris *pt, Block *pbd)
{
    int key;

    if (read(fileno(stdin), &key, 1) < 0)
        return TE_ERR;

//        printf("0x%X, %c\n", key&0xFF, key);

    switch (key & 0xFF)
    {
        case ' ':
        {
            int org_form = pt->form;
            pt->form = (pt->form + 1) % pt->total_form;
            rotate_tetris(pt);

            if ( is_tetris_collide(pt, pbd) ) /* return to its original form */
                while (pt->form != org_form) 
                {
                    pt->form = (pt->form + 1) % pt->total_form;
                    rotate_tetris(pt);
                }

            break;
        }

            /* no upward support */
/*            case 'i': */
/*                move_tetris(pt, TO_UP); */
/*                break; */

        case 's':
            move_tetris(pt, TO_DOWN);
            if( is_tetris_collide(pt, pbd) )
                move_tetris(pt, TO_UP);
            break;

        case 'a':
            move_tetris(pt, TO_LEFT);
            if ( is_tetris_collide(pt, pbd) )
                move_tetris(pt, TO_RIGHT);                    
            break;

        case 'd':
            move_tetris(pt, TO_RIGHT);
            if ( is_tetris_collide(pt, pbd) )
                move_tetris(pt, TO_LEFT);
            break;

        case 'p':
            do {
                while (read(fileno(stdin), &key, 1) < 0);
            } while (key != 'p') ;
            break;

        case 'q':
            g_bquit = 1;
            return TE_ERR;

        default:
            break;
    }

    return TE_OK;
}


/* DONE ! */
/* the major game process, control part */
int
process_game(int speed)
{
    int timer;
    sc *pscr = NULL;
    Block *pbd = NULL;
    Tetris *pt = NULL;

    /* malloc needed memory */
    pscr = (char*)malloc(ROW_MAX*COL_MAX);
    if (pscr == NULL)
    {
        fprintf(stderr, "malloc memory error!\n");
        exit(EXIT_FAILURE);
    }

    /* ok, begin our games */
    CLEAR_SCR();
    generate_a_tetris(&pt);

    for (timer=0; !g_bquit; timer++)
    {
        if (timer > speed)
            timer = 0;
        
        usleep(1000);

        if (control_tetris_and_wait(pt, pbd) == TE_OK
            || !timer)
        {
        UPDATE_SCREEN:
            CLEAR_SCR();
            mark_in_scr_buf(pt, pbd, pscr);
            invalidate_screen(pscr);
        }

        if (!timer)
            move_tetris(pt, TO_DOWN);

        /* collide with dirty blocks */
        if (is_tetris_collide(pt, pbd))
        {
            while (is_tetris_collide(pt, pbd)) /* to compasate */
                move_tetris(pt, TO_UP);
            calc_line_marks_of_blocks(pt); /* before connect */
            connect_tetris_and_blocks(&pt, &pbd);

            if (be_remove_blocks_when_full(&pbd))
                update_line_marks_of_blocks(pbd);

            generate_a_tetris(&pt);

            goto UPDATE_SCREEN;
        }
    } /* end of for */

    /* free at the end, don't leave it to OS */
    if (pscr != NULL)
    {
        free(pscr);
        pscr = NULL;
    }

    if (pt != NULL)
    {
        Block *p;
        for (p=pt->pb; p; p=pt->pb)
        {
            pt->pb = p->pn;
            free(p);
        }
        free(pt);
    }

    if (pbd != NULL)
    {
        Block *p;
        for (p=pbd; p; p=pbd)
        {
            pbd = pbd->pn;
            free(p);
        }
    }

    return TE_OK;
}

/* TO BE CONTINUED !*/
/* setting terminal, no ECHO, no buffering */
int
setting_terminal(int bset)
{
    int termfl;
    struct termios po;

    if (tcgetattr(fileno(stdin), &po) != 0)
        PERR("get attr");

    if (bset)
        po.c_lflag &= ~(ECHO | ICANON);
    else
        po.c_lflag |= (ECHO | ICANON);

    if (tcsetattr(fileno(stdin), TCSANOW, &po) != 0)
        PERR("set attr");


    if (fcntl(fileno(stdin), F_GETFL, &termfl) != 0)
        PERR("get fcntl");


    if (bset)
        termfl = termfl | O_NDELAY | O_NONBLOCK;
    else
        termfl = termfl & ~(O_NDELAY | O_NONBLOCK);

    if (fcntl(fileno(stdin), F_SETFL, termfl) != 0)
        PERR("set fcntl");
    
    return TE_OK;
}

void
logo(char *bin)
{
    int key;
    CLEAR_SCR();
    printf("#!/bin/bash\n");
    printf("#\n");
    printf("# Usage: %s (speed, eg. 300)\n", bin);
    printf("#\n");
    printf("# by suchaaa AT gmail DOT com, %s,\n", __DATE__);
    printf("# and just for fun!\n");
    printf("#\n");
    printf("#\n");
    printf("# SPACE: transform\n");
    printf("#  'a' : move left\n");
    printf("#  's' : move down\n");
    printf("#  'd' : move right\n");
    printf("#  'p' : pause\n");
    printf("#  'q' : quit\n");
    printf("#\n");
    printf("#\n");
    printf("# any key to continue...\n");
    printf("#\n");
    while (read(fileno(stdin), &key, 1) < 0);
}

int
main(int argc, char *argv[])
{
    int speed;
    
    if (argc == 1)
    {
        speed = SPEED_VAL;
    }
    else if (argc == 2)
    {
        speed = atoi(argv[1]);
    }
    else
    {
        fprintf(stdout, "usage: a.exe OR a.exe rows cloumns\n");
        return 0;
    }

    setting_terminal(true);   // first setting terminal
    logo(argv[0]);
    process_game(speed);
    setting_terminal(false);    // first setting terminal

    return 0;
}

/* tetris.c ends here */
