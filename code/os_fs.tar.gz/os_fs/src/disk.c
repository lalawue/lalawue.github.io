/* disk.c */

#include "disk.h"

/* toggle the free blocks, the blocks count from 0 after inode_table */
int fs_toggle_free_block(FILE *fp)
{
    fseek( fp, sizeof(struct fs_boot), SEEK_SET); /* skip boot block */
    struct fs_super super;
    fread( &super, sizeof(super), 1, fp);

    /* skip boot, super and inode_table */
    fseek( fp, BLOCK_SIZE*(INODE_TABLE_BLOCKS + 1), SEEK_SET);

    int r, i, blk_stack[STACK_MAX+1];    /* toggle the free blocks here */
    for( r=0, i=0; r<super.free_block_count; r++){

	if(r%STACK_MAX==0 && r>0){

 	    blk_stack[0] = STACK_MAX;
	    fwrite( &blk_stack, sizeof(blk_stack), 1, fp);
	    fseek( fp, BLOCK_SIZE*(INODE_TABLE_BLOCKS + 1 + STACK_MAX*i++), SEEK_SET);
	}

	blk_stack[(r%STACK_MAX) + 1] = r; /* jump to next group */
    }

    /* record the rest in the last */
    blk_stack[0] = super.free_block_count - ftell(fp)/BLOCK_SIZE;
    fwrite( &blk_stack, sizeof(blk_stack), 1, fp);

    return 0;
}

/* format the file system */
int fs_format(FILE *fp)
{
    int i;
    rewind(fp);

    struct fs_boot boot;	/* rubbish boot block: 512 B */
    fwrite( &boot, sizeof(boot), 1, fp);

    struct fs_super super;    /* initialize the super block */
    super.total_block_count = DISK_SIZE/BLOCK_SIZE;
    super.free_block_count = super.total_block_count - (INODE_TABLE_BLOCKS + 1);

    for( i=0; i<STACK_MAX; i++){
	super.free_block_stack[i+1] = i;   /* from index 1 */
	super.free_inode_stack[i+1] = i;   /* from index 1 */
    }
    super.free_block_stack[0] = STACK_MAX;
    super.free_inode_stack[0] = STACK_MAX;

    super.free_inode_count = INODE_TABLE_BLOCKS*BLOCK_SIZE/sizeof(struct fs_inode);
    super.remembered_inode = STACK_MAX;
    fwrite( &super, sizeof(super), 1, fp);

    for( i=0; ftell(fp)<BLOCK_SIZE; i++) /* fillin until  one blocks */
	fwrite( &i, sizeof(i), 1, fp);

    struct fs_inode inode;	/* write inode_talbe */
    inode.type = 'i';		/* mark as free inode, see disk.h */
    for( i=0; i<INODE_TABLE_BLOCKS*BLOCK_SIZE/sizeof(inode); i++)
	fwrite( &inode, sizeof(inode), 1, fp);

    struct fs_block block;	/* write the data block, just fill */
    for( i=0; i<super.free_block_count; i++)
	fwrite( &block, sizeof(block), 1, fp);

    fs_toggle_free_block(fp);	/* toggle the free blocks */

    return 0;
}
