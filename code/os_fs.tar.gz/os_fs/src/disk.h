/* disk.h */

#ifndef _DISC_H
#define _DISC_H 0

#include <stdio.h>
#include <stdlib.h>

#define DISK_SIZE 1024*1024*10	/* disc size: 10 MB */
#define BLOCK_SIZE 4096		/* block size: 4096 B */
#define INODE_TABLE_BLOCKS 30	/* blocks for store inode */
#define STACK_MAX 50		/* free block, free inode capacity */

struct fs_block{
    int size[BLOCK_SIZE/sizeof(int)]; /* 4096 B */
};

struct fs_boot{
    int size[BLOCK_SIZE/8/sizeof(int)]; /* 512 B */
};

/* free_block_stack: index(0) contains the currrent index
   free_inode_stack: index(0) contains the currrent index
 */
struct fs_super{
    int total_block_count;	/* total block count */
    int free_block_stack[STACK_MAX+1]; /* free block stack */
    int free_block_count;	/* current free block quantity */
    int free_inode_stack[STACK_MAX+1]; /* free inode stack */
    int free_inode_count;	/* current free inode quantity */
    int remembered_inode;	/* the last unregister inode pos */
};

/* inode_table capacity = INODE_TABLE_BLOCKS * BLOCK_SIZE
   TYPE: 'i' ~ free, 'f' ~ file, 'd' ~ directory */
struct fs_inode{
    char user[15];		/* user name */
    char type;			/* file type */
    unsigned links;		/* links to the file */
    int size;			/* file size */
    int addr[13];		/* disk addr */
};


int fs_format(FILE *fp);	/* format the new file */

int fs_init(FILE *fp);		/* init the fs */

#endif	/* _DISC_H */
