/* fd.h */

#ifndef _FD_H
#define _FD_H 0

#include "block.h"
#include "inode.h"
#include <math.h>
#include <string.h>

/* SEEK_BLK(blk_no) IMPLIES boot, super and inode_table contains in one block */
#define SEEK_BLK(blk_no)  BLOCK_SIZE*(INODE_TABLE_BLOCKS + 1 + blk_no)
#define NAME_LEN 14
#define PATH_LEN 100

struct fd_entry{
    char name[NAME_LEN];	/* file or dir name */
    int inode_no;		/* inode number */
};

struct blk_index{		/* block index in indirect addr*/
    int blk_no;
};

struct fs_inode find_inode( FILE *fp, int ind_no);

struct fd_entry find_entry( FILE *fp, int dir_ind_no, int file_inode_no);

int fd_exist( FILE *fp, int ind_no, const char *fd_name);

int blk_map( FILE *fp, int ind_no, long offset);

int alc_blk( FILE *fp, int ind_no);

int create_fd( FILE *fp, int dir_ind_no, const char *file, const char given_type, const char *f_size);

int remove_fd( FILE *fp, int dir_ind_no, const char *file);

#endif	/* _FD_H */
