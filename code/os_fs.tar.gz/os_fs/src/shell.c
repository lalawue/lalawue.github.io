/* shell.c */

#include "shell.h"

/* setup root dir, allocate inode and block, add file entry. 
   return root's inode number. */
int fs_setup(FILE *fp)
{
    char *self=".";
    struct fd_entry root_entry;
    strcpy( root_entry.name, self);
    root_entry.inode_no = get_ind(fp);

    char *user = "user";
    struct fs_inode root_inode;
    strcpy( root_inode.user, user);
    root_inode.type = 'd';
    root_inode.links = 1;
    root_inode.size = 2*sizeof(root_entry);
    root_inode.addr[0] = get_blk(fp);
    update_ind( fp, root_entry.inode_no, root_inode);

    fseek( fp, SEEK_BLK(root_inode.addr[0]), SEEK_SET);
    fwrite( &root_entry, sizeof(root_entry), 1, fp);

    char *parent = "..";
    strcpy( root_entry.name, parent);
    fseek( fp, SEEK_BLK(root_inode.addr[0])+sizeof(root_entry), SEEK_SET);
    fwrite( &root_entry, sizeof(root_entry), 1, fp);

    return root_entry.inode_no;
}

/* this function provide an small shell, 
   it need 2 env variable (*fp) and (*pd_ind_no) */
 void shell( FILE *fp, int *pd_ind_no)
{
    printf("##########################################\n"
	   "#  Welcome to the Small UNIX Filesystem  #\n"
	   "##########################################\n"
	   "Login as tuu, in " __DATE__ " " __TIME__ "\n\n");
    
    help();

    int i;
    char command[MAX_COMMAND_LEN], ch, path[STACK_MAX];

    while(1){
	pwd( fp, pd_ind_no, path);
	fprintf( stdout, "tuu@hfut:%s$ ", path);
	fflush(stdout);
	
	for( i=0; (ch=fgetc(stdin)) != '\n'; i++){
	    command[i] = ch;
	};
	command[i] = '\0';

	processor( command, fp, pd_ind_no, path);
    };
    return;
}

int main(int argc, char *argv[])
{
    int dir_ind_no, *pd_ind_no;
    char *file = "FS_DISK";
    FILE *fp;

    if(argc > 1)
	file = argv[1];

    if((fp=fopen( file, "r+b")) == NULL){
	fprintf( stderr, "Creating file %s, and ", file);

	fp = fopen( file, "w+b");
	fclose(fp);

	fp = fopen( file, "r+b");
	fs_format(fp);		   /* create disk and format fs */
	dir_ind_no = fs_setup(fp); /* set up fs, then get the root inode number */
    }
    else{
	dir_ind_no = STACK_MAX - 1; /* get the root inode number */
    }
    printf("use file %s as a hard disk.\n", file);

//    test_part(fp);
    pd_ind_no = &dir_ind_no;
    shell( fp, pd_ind_no);

    fclose(fp);

    return 0;
}

void test_part(FILE *fp)
{
/*     test_blk_map(fp); */
/*     fs_format(fp); */
/*     test_info(fp); */
/*     test_blk(fp); */
/*     test_ind(fp); */
//    test_mk_fd(fp);
    test_alc_blk(fp);
}
