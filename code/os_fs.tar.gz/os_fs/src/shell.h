/* shell.h */

#ifndef _SHELL_H
#define _SHELL_H 0

#include "fd.h"
#include "command.h"
#include "tester.h"

void test_part(FILE *fp);

int fs_setup(FILE *fp);

void shell(FILE *fp, int *pd_ind_no);

#endif	/* _SHELL_H */
