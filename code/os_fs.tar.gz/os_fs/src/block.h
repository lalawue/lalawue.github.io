/* block.h */

#ifndef _BLOCK_H
#define _BLOCK_H 0

#include "disk.h"

int get_blk(FILE *fp);

int free_blk(FILE *fp, int blk_no);

#endif	/* _BLOCK_H */
