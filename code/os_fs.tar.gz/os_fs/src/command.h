/* command.h */


#ifndef _COMMAND_H
#define _COMMAND_H 0

#include "fd.h"

#define MAX_COMMAND_LEN 20

struct sh_command{
    char com[MAX_COMMAND_LEN];
    int no;
    char *argv;
    char *description;
};

void processor( const char *command, FILE *fp, int *pd_ind_no, char *path);

char *pick_arg( int argc, char *argv);

/* command part */

void help();

void list_dir( FILE *fp, int dir_ind_no);

int cd_path( FILE *fp, int *pd_ind_no, char *path);

void status( FILE *fp);

void re_name( FILE *fp, int dir_ind_no, char *f1, char *f2);

void pwd( FILE *fp, int *pd_ind_no, char *path);

void move_file( FILE *fp, int *pd_ind_no, char *file, char *to_path);

void link_file( FILE *fp, int *pd_ind_no, char *file, char *to_path);

#endif	/* _COMMAND_H */
