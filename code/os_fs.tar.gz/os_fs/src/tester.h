/* tester.h */

#ifndef _TESTER_H
#define _TESTER_H 0

#include "fd.h"

void test_blk_map(FILE *fp);

void test_blk(FILE *fp);

void test_ind(FILE *fp);

void test_info(FILE *fp);

void test_mk_fd(FILE *fp);

void test_alc_blk(FILE *fp);

#endif	/* _TESTER_H */
