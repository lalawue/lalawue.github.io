/* tester.c */

#include "tester.h"

/* until establish the create file and mkdir prog */
/* void test_fd_exist(FILE *fp) */
/* { */
    
/* } */

void test_blk_map(FILE *fp)
{
    struct fs_inode inode;
    int i, ind_no;

    /* test direct */
    ind_no = get_ind(fp);
    for( i=0; i<10; i++){
	inode.addr[i] = get_blk(fp);
    }
    inode.type = 'f';
    inode.size = BLOCK_SIZE * 10;
    update_ind( fp, ind_no, inode);

    printf("locate file blk: %d\n", blk_map( fp, ind_no, 4095));

    /* test single, first create file use indirect */
}

void test_info(FILE *fp)
{
    fseek( fp, sizeof(struct fs_boot), SEEK_SET);
    struct fs_super super;
    fread( &super, sizeof(super), 1, fp);

    printf("total blk: %d\nfree_block_count %d\nfree_inode_count %d\n", 
	   super.total_block_count, 
	   super.free_block_count,
	   super.free_inode_count);
    
//    printf("inode number: %d\n", INODE_TABLE_BLOCKS*BLOCK_SIZE/sizeof(struct fs_inode));
    printf("fs_inode sizeof: %d\n", sizeof(struct fs_inode));

    printf("boot, super and inode: %d\n", INODE_TABLE_BLOCKS+1);
    printf("blk locate in: %d\n", SEEK_BLK(4)/BLOCK_SIZE);
}

void test_blk(FILE *fp)
{
    /* test alloc_blk */
    fseek( fp, sizeof(struct fs_boot), SEEK_SET);
    struct fs_super super;
    fread( &super, sizeof(super), 1, fp);
    printf("super: %d\n", super.free_block_count);

    int i, stack[super.free_block_count];
    for( i=0; i<super.free_block_count; i++){
	stack[i] = get_blk(fp);
	printf("get blk:  %d\n", stack[i]);
    }
    for( i=0; i<super.free_block_count; i++){
	free_blk( fp, stack[i]);
    }
    for( i=0; i<super.free_block_count; i++){
	stack[i] = get_blk(fp);
	printf("get blk:  %d\n", stack[i]);
    }
    for( i=0; i<super.free_block_count; i++){
	free_blk( fp, stack[i]);
    }
    for( i=0; i<super.free_block_count; i++){
	stack[i] = get_blk(fp);
	printf("get blk:  %d\n", stack[i]);
    }
}

void test_ind(FILE *fp)
{
    fseek( fp, sizeof(struct fs_boot), SEEK_SET);
    struct fs_super super;
    fread( &super, sizeof(super), 1, fp);
    printf("free inode: %d\n", super.free_inode_count);
    printf("first inode: %d\n", super.free_inode_stack[STACK_MAX]);

    int i, stack[super.free_inode_count];
    for( i=0; i<super.free_inode_count; i++){
	stack[i] = get_ind(fp);
//	printf("get inode: %d\n", stack[i]);
    }
    for( i=super.free_inode_count-1; i>=0; i--){
	free_ind( fp, stack[i]);
//	printf("free inode: %d\n", stack[i]);
    }
/*     for( i=0; i<10; i++){ */
/* 	stack[i] = get_ind(fp); */
/* 	printf("get inode: %d\n", stack[i]); */
/*     } */
/*     for( i=79; i>=0; i--){ */
/* 	free_ind( fp, stack[i]); */
/* 	printf("free inode: %d\n", stack[i]); */
/*     } */
}

/* test to create a file and dir in '/' directory */
void test_mk_fd(FILE *fp)
{
    char *file="test.c", *dir="bin/", *user="user";
    /* first to construct the file and dir entry */
    struct fd_entry file_entry, dir_entry;
    strcpy( file_entry.name, file);
    file_entry.inode_no = get_ind(fp);

    strcpy( dir_entry.name, dir);
    dir_entry.inode_no = get_ind(fp);

    /* second to update the '/' directory */
    struct fs_inode root_inode = find_inode( fp, 49);
    fseek( fp, (SEEK_BLK(root_inode.addr[0])+root_inode.size), SEEK_SET);
    fwrite( &file_entry, sizeof(file_entry), 1, fp);
    fwrite( &dir_entry, sizeof(dir_entry), 1, fp);
    
    root_inode.size += 2*sizeof(file_entry);
    update_ind( fp, 49, root_inode);
    
    
    /* finally to init the dir and file inode information */
    struct fs_inode file_inode, dir_inode;

    file_inode = find_inode( fp, file_entry.inode_no);
    strcpy( file_inode.user, user);
    file_inode.type  = 'f';
    file_inode.links = 1;
    file_inode.size = 0;
    file_inode.addr[0] = get_blk(fp);
    update_ind( fp, file_entry.inode_no, file_inode);

    dir_inode = find_inode( fp, dir_entry.inode_no);
    strcpy( dir_inode.user, user);
    dir_inode.type  = 'd';
    dir_inode.links = 1;
    dir_inode.size  = 2*sizeof(dir_entry);
    dir_inode.addr[0] = get_blk(fp);
    update_ind( fp, dir_entry.inode_no, dir_inode);

    char *self=".", *parent="..";
    struct fd_entry dir_tmp_entry;
    strcpy( dir_tmp_entry.name, self);
    dir_tmp_entry.inode_no = dir_entry.inode_no;

    fseek( fp, SEEK_BLK(dir_inode.addr[0]), SEEK_SET);
    fwrite( &dir_tmp_entry, sizeof(dir_tmp_entry), 1, fp);

    strcpy( dir_tmp_entry.name, parent);
    dir_tmp_entry.inode_no = 49; /* root inode number */
    fwrite( &dir_tmp_entry, sizeof(dir_tmp_entry), 1, fp);
}

void test_alc_blk(FILE *fp)
{
    int ind_no = get_ind(fp), i;
    struct fs_inode inode;
    strcpy( inode.user, "user");
    inode.type = 'f';
    inode.links = 1;
    inode.size = 0;
    for( i=0; i<13; i++)
	inode.addr[i] = -1;
    update_ind( fp, ind_no, inode);
    for( i=0; i<70; i++)
	printf("%d\n", alc_blk( fp, ind_no));
    printf("\n");
}
