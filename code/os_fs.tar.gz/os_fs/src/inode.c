/* inode.c */

#include "inode.h"

/* return inode numbers, and return -1 if free inode is nil */
int get_ind(FILE *fp)
{
    struct fs_super super;
    fseek( fp, sizeof(struct fs_boot), SEEK_SET); /* skip boot block */
    fread( &super, sizeof(super), 1, fp);

    int i, ind_no;
    if(super.free_inode_count > 0){ /* if more than one block */
	i = super.free_inode_stack[0];
	ind_no = super.free_inode_stack[i];

	super.free_inode_stack[0] -= 1;
	super.free_inode_count--;

	/* if stack was empty and free blocks not nil, update the stack */
	if((super.free_inode_stack[0]==0) && (super.free_inode_count>0)){
	    int j = 0;
	    struct fs_inode inode;

	    for( i=super.remembered_inode; i<TOTAL_INODES; i++){
		fseek( fp, INODE_OFFSET(i), SEEK_SET);
		fread( &inode, sizeof(inode), 1, fp);

		if(inode.type == 'i'){
		    super.free_inode_stack[0] += 1;
		    j = super.free_inode_stack[0];

		    super.free_inode_stack[j] = i;
		}

		if(j == STACK_MAX){
		    super.remembered_inode = i + 1;
		    break;
		}
	    }
	} /* end of if */

	fseek( fp, sizeof(struct fs_boot), SEEK_SET); /* write back */
	fwrite( &super, sizeof(super), 1, fp);
	
	return ind_no;
    }
    else
	return -1;
}


int free_ind( FILE *fp, int ind_no)
{
    struct fs_inode inode;	/* write the free inode back to inode table*/
    inode.type = 'i';		/* mark as free */
    fseek( fp, INODE_OFFSET(ind_no), SEEK_SET);
    fwrite( &inode, sizeof(inode), 1, fp);

    struct fs_super super;	/* update the super */
    fseek( fp, sizeof(struct fs_boot), SEEK_SET);
    fread( &super, sizeof(super), 1, fp);

    int i;
    if(super.free_inode_stack[0] == STACK_MAX &&
       super.remembered_inode > ind_no)
    {
	super.remembered_inode = ind_no;
    }
    else if(super.free_inode_stack[0] < STACK_MAX){
	super.free_inode_stack[0] += 1;
	i = super.free_inode_stack[0];
	super.free_inode_stack[i] = ind_no;
    }
    /* else the ind_no locate in next free inode collecting */

    fseek( fp, sizeof(struct fs_boot), SEEK_SET); /* write back */
    fwrite( &super, sizeof(super), 1, fp);

    return 0;
}

/* update the provider inode data */
int update_ind( FILE *fp, int ind_no, struct fs_inode inode)
{
    fseek( fp, INODE_OFFSET(ind_no), SEEK_SET);
    fwrite( &inode, sizeof(inode), 1, fp);

    return 0;
}
