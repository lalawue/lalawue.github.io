/* block.c */

#include "block.h"

/* return: block numbers, and return -1 if free blocks is nil */
int get_blk(FILE *fp)
{
    struct fs_super super;

    fseek( fp, sizeof(struct fs_boot), SEEK_SET); /* skip boot block */
    fread( &super, sizeof(super), 1, fp);

    int i, blk_no;
    if(super.free_block_count > 0){ /* if more than one block */
	i = super.free_block_stack[0];
	blk_no = super.free_block_stack[i];

	super.free_block_stack[0] -= 1; /* update the relative variable */
	super.free_block_count--;

	/* if stack was empty and free blocks not nil, update the stack */
	if((super.free_block_stack[0]==0) && (super.free_block_count>0)){

	    fseek( fp, BLOCK_SIZE*(INODE_TABLE_BLOCKS + 1 + blk_no), SEEK_SET);
	    fread( &super.free_block_stack, sizeof(super.free_block_stack), 1, fp);
	}
	
	fseek( fp, sizeof(struct fs_boot), SEEK_SET);
	fwrite( &super, sizeof(super), 1, fp);

	return blk_no;
    }
    else			/* if free blocks is none*/
	return -1;
}


int free_blk(FILE *fp, int blk_no)
{
    struct fs_super super;
    fseek( fp, sizeof(struct fs_boot), SEEK_SET);
    fread( &super, sizeof(super), 1, fp);

    int i;
    if(super.free_block_stack[0] == STACK_MAX){ /* if stack was full */

	/* first write the stack to the new block */
	fseek( fp, BLOCK_SIZE*(INODE_TABLE_BLOCKS + 1 + blk_no), SEEK_SET);
	fwrite( &super.free_block_stack, sizeof(super.free_block_stack), 1, fp);

	super.free_block_count++; /* update the super */
	super.free_block_stack[0] = 1;
	super.free_block_stack[1] = blk_no;
    }
    else{
	super.free_block_count++;

	super.free_block_stack[0] += 1;
	i = super.free_block_stack[0];
	super.free_block_stack[i] = blk_no;
    }

    fseek( fp, sizeof(struct fs_boot), SEEK_SET); /* write back */
    fwrite( &super, sizeof(super), 1, fp);

    return 0;
}
