/* inode.h */

#ifndef _INODE_H
#define _INODE_H 0

#include "block.h"

#define TOTAL_INODES (BLOCK_SIZE*INODE_TABLE_BLOCKS/sizeof(struct fs_inode))
/* the INODE_OFFSET(x) implies boot + super contains in one block */
#define INODE_OFFSET(x) (BLOCK_SIZE + (x)*sizeof(struct fs_inode))

int get_ind(FILE *fp);

int free_ind( FILE *fp, int ind_no);

int update_ind( FILE *fp, int ind_no, struct fs_inode inode);

#endif	/* _INODE_H */
